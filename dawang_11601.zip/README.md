# 11601-summary-stat-nodejs

nodejs homework for 11601 coding bootcamp

## How to use

1. open terminal
2. node parser.js filename

If the user don't specify the filename parameter, the code will use the default one.

Output HTML will be `filename-result.html` in the same folder.

For more detail, please visit [my blog](http://wdxtub.com/2015/12/04/nodejs-cmd-tutorial/)
